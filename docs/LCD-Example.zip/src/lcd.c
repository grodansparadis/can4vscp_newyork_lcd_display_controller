/*
 *	Subsystem		:	nanoTRONICS24 Development Board - LCD Library
 *
 * 	File Name		:	lcd.c
 * 	
 * 	Author			:	Modtronics Development Team
 * 	
 * 	Creation Date	:	03/11/2013
 * 	
 * 	Description		:	This module is responsible for initialising, writing to and controlling
 * 	                    the a standard 8x2 or 16x2 alphanumeric LCD module.
 * 	                    Currently this module only supports LCDs in 4-bit mode (ie D4-D7 used). 
 * 	                    Pins can be configured using the definies in lcd.h file
 * 	                    
 * � Modtronics Australia 2013
 * www.modtronicsaustralia.com
 *
 */

#include "lcd.h"


/*
 *  Initialise the LCD - Set all the IO pins into the correct mode
 *                       Reset the LCD
 *                       Set the LCD into 4-bit mode
 *                       Setup the font and cursor blinking mode etc
*/

void lcdInitialise( void )
{
    // Setup port pins - set all to outputs
    LCD_RS_TRIS = OUTPUT_PIN;
    LCD_RW_TRIS = OUTPUT_PIN;
    LCD_E_TRIS = OUTPUT_PIN;
    LCD_D4_TRIS = OUTPUT_PIN;
    LCD_D5_TRIS = OUTPUT_PIN;
    LCD_D6_TRIS = OUTPUT_PIN;
    LCD_D7_TRIS = OUTPUT_PIN;

    LCD_RS_PIN = 0;	    // Put the LCD into command mode
    LCD_RW_PIN = 0;     // Put the LCD into writing mode
    __delay_ms( 20 );	// power on delay
    
    // Setup the relevant data pins to reset the LCD (DATA = 0x03)
    LCD_D4_PIN = 1;
    LCD_D5_PIN = 1;
    // Carry out LCD reset sequence
    __delay_us( 5 );
    lcdStrobe();
    __delay_ms( 10 );
    lcdStrobe();
    __delay_ms( 10 );
    lcdStrobe();
    __delay_ms( 5 );

    // Place the LCD into 4-bit mode (DATA = 0x02)
    LCD_D4_PIN = 0;
    lcdStrobe();
    __delay_ms( 1 );

    lcdWriteCommand( 0x28 );	// LCD 4-bit mode; 1/16 duty; 5x8 font
    lcdWriteCommand( 0x28 );	// LCD 4-bit mode; 1/16 duty; 5x8 font
    lcdWriteCommand( 0x08 );	// Turn display off
    lcdWriteCommand( 0x0C );	// Turn display on; blink cursor off
    lcdWriteCommand( 0x06 );	// Set LCD entry mode
}

/*
 *  LCD Strobe - this function clocks the data on the pins D4-D7 into
 *  the LCD's buffer
*/
void lcdStrobe( void )
{
    __delay_us( 5 ); 
    LCD_E_PIN = 1;
    __delay_us( 5 );
    LCD_E_PIN = 0;
    __delay_us( 5 );
}


/*
 *  LCD Write Command - this function writes a command to the LCD's
 *  command buffer.
 *  
*/
void lcdWriteCommand( uint8_t iCmd )
{
    
    uint8_t cmdCopy;


    // Write the top nibble of the command
    cmdCopy = (iCmd & 0xF0) >> 4;
    LCD_D4_PIN = (cmdCopy >> 0) & 0x01;
    LCD_D5_PIN = (cmdCopy >> 1) & 0x01;
    LCD_D6_PIN = (cmdCopy >> 2) & 0x01;
    LCD_D7_PIN = (cmdCopy >> 3) & 0x01;
    lcdStrobe();
    // Write the bottom nibble of the command
    cmdCopy = (iCmd & 0x0F);
    LCD_D4_PIN = (cmdCopy >> 0) & 0x01;
    LCD_D5_PIN = (cmdCopy >> 1) & 0x01;
    LCD_D6_PIN = (cmdCopy >> 2) & 0x01;
    LCD_D7_PIN = (cmdCopy >> 3) & 0x01;
    lcdStrobe();
    __delay_us( 40 );

}

/*
 *  LCD Write Character - this function writes a character
 *  to the LCD's character buffer. Note, just like commands
 *  characters need to be written a nibble at a time
 *  
*/
void lcdWriteCharacter( uint8_t iChar )
{
    
    uint8_t characterCopy;
    // Put the LCD into data mode
    LCD_RS_PIN = 1;
     // Write the top nibble of the character
    characterCopy = (iChar & 0xF0) >> 4;
    LCD_D4_PIN = (characterCopy >> 0) & 0x01;
    LCD_D5_PIN = (characterCopy >> 1) & 0x01;
    LCD_D6_PIN = (characterCopy >> 2) & 0x01;
    LCD_D7_PIN = (characterCopy >> 3) & 0x01;
    lcdStrobe();
     // Write the bottom nibble of the character
    characterCopy = (iChar & 0x0F);
    LCD_D4_PIN = (characterCopy >> 0) & 0x01;
    LCD_D5_PIN = (characterCopy >> 1) & 0x01;
    LCD_D6_PIN = (characterCopy >> 2) & 0x01;
    LCD_D7_PIN = (characterCopy >> 3) & 0x01;
    lcdStrobe();
    __delay_us( 40 );


}

/*
 *  LCD Printf - this function prints a string of characters
 *  to the LCD.
 *  
*/
void lcdPrintf( const char *iString )
{
    // Put the LCD into data (character) mode
    LCD_RS_PIN = 1;	
    while (*iString)
    {
        lcdWriteCommand( *iString++ );
    }
}

/*
 *  LCD Printf Line One - Print the passed string to the first
 *  line on the LCD
 *  
*/
inline void lcdPrintfLineOne( const char *iString )
{
    lcdGotoPosition( 0x00 );
    lcdPrintf( iString );
}

/*
 *  LCD Printf Line Two - Print the passed string to the second
 *  line on the LCD
 *  
*/
inline void lcdPrintfLineTwo( const char *iString )
{
    lcdGotoPosition( 0x40 );
    lcdPrintf( iString );
}

/*
 *  LCD Clear - This function clears the LCD 
 *  
*/
void lcdClear( void )
{
    LCD_RS_PIN = 0;
    lcdWriteCommand( 0x01 );
    __delay_ms( 2 );
}


/*
 *  LCD Write Character Generator RAM (CGRAM) - This function can be
 *  used to create custom characters on the LCD
 *  
*/
void lcdWriteCharGenRAM( uint8_t iCharPosition, const char *iChar )
{
    
    uint8_t i = iCharPosition << 3;
    uint8_t j;

    LCD_RS_PIN = 0;
    lcdWriteCommand( 0x40 + i );	
    LCD_RS_PIN = 1;
    for (j = 0; j < 8; j++)
    {
        lcdWriteCommand( iChar[j] );
    }
}


/*
 *  LCD GOTO Position - This function move the LCD cursor to the
 *  specified position on the screen
 *  
*/
void lcdGotoPosition( uint8_t iPosition )
{
    LCD_RS_PIN = 0;
    lcdWriteCommand( 0x80 + iPosition );
}

/*
 *  LCD Turn Off - This function turns off the LCD
 *  
*/
void lcdTurnOff( void )
{
    lcdClear();
    LCD_RS_PIN = 0; 
    lcdWriteCommand( 0x08 ); 
}


/*
 *  Scroll LCD Line One - Scroll the first line of the LCD by one character
 *  to the left
 *  
*/
uint8_t lcdScrollLineOne( const char *iString, uint8_t iCurrentPosition )
{
    iString += iCurrentPosition;
    lcdPrintfLineOne( iString );
    return iCurrentPosition++;
}

/*
 *  Scroll LCD Line Two - Scroll the second line of the LCD by one character
 *  to the left
 *  
*/
uint8_t lcdScrollLineTwo( const char *iString, uint8_t iCurrentPosition )
{
    iString += iCurrentPosition;
    lcdPrintfLineTwo( iString );
    return iCurrentPosition++;
}

