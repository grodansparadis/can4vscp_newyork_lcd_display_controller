/*
 *	Subsystem		:	nanoTRONICS24 Development Board - LCD Example code
 *
 * 	File Name		:	main.c
 * 	
 * 	Author			:	Modtronics Development Team
 * 	
 * 	Creation Date	:	06/11/2013
 * 	
 * 	Description		:	This project is contains demo code to control a LCD
 * 	                    connected to our nanoTRONICS24 development board.
 * 	                    The code in this file (main.c) scrolls two lines of
 * 	                    text across the LCD using the functions provided in our
 * 	                    LCD library (lcd.h and lcd.c).
 * 	                    
 * 	                    Compiler XC16 v1.1 - http://www.microchip.com/mplabxc16windows
 * 	                    
 * � Modtronics Australia 2013
 * www.modtronicsaustralia.com
 *
 */

// *********************System Includes***************************
// Hardware specific
#include "HardwareProfile.h"
#include "configwords.h"
// Microchip include files
#include <xc.h>
#include <libpic30.h>
#include <stdint.h>
#include <string.h>
// Project based includes
#include "lcd.h"


inline void configureBoard(void);
inline void configurePortPins(void);


int main(void)
{

    uint8_t i = 0;

    // Configure board hardware - ie pin directions and clock setup
    configureBoard();

    // Initialise the LCD - for 4-bit mode operation
    lcdInitialise();

    // Clear the LCD
    lcdClear();

    // Enter main program loop
    while (1) 
    {
        const char lineOneText[] = "nanoTRONICS24 - PIC24 Development Board";
        const char lineTwoText[] = "http://modtronicsaustralia.com/";
        uint8_t lengthLong = strlen( lineOneText );
        uint8_t lengthShort = strlen( lineTwoText );

        // Print the two lines of text
        lcdPrintfLineOne( lineOneText );
        lcdPrintfLineTwo( lineTwoText );

        __delay_ms( 3500 );

        // Scroll the text to the left
        for (i = 0; i < (lengthLong - 15); i++)
        {
            lcdScrollLineOne( lineOneText, i );
            if ((lengthShort - i - 15) > 0)
            {
                lcdScrollLineTwo( lineTwoText, i );
            }
            __delay_ms( 1250 );
        }
        __delay_ms( 1000 );
        lcdClear();


    } 

} //end main

/******************************************************************************
 * Function:        inline void configureBoard()
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function configures the board hardware including the following:
 *					+ Clock source used - FRC (internal) or external XTAL
 *					+ Calls the pin configuration function - that sets up data directions on applicable
 *					  pins
 *                  + Calls the peripheral pin select (PPS) configuration function - which sets which pins
 *                    to use for peripherals like the UART or SPI.
 *
 *
 * Note:            
 *
 *****************************************************************************/
inline void configureBoard(void)
{

    unsigned int pllCounter;
    OSCCONBITS OSCCONbitsCopy;

    // Copy Current Clock Setup
    OSCCONbitsCopy = OSCCONbits;
    // Slow output clock down to 4Mhz
    CLKDIVbits.CPDIV = 3;
    // Enable PLL - Note: Fuse bits don't do this
    CLKDIVbits.PLLEN = 1;
    for (pllCounter = 0; pllCounter < 600; pllCounter++);

    // Check to see what clock setup is defined
    #ifdef USE_FRC_CLOCK
        // Setup the uC to use the internal FRCPLL mode
        OSCCONbitsCopy.NOSC = 1;
        OSCCONbitsCopy.OSWEN = 1;
    #else
        // Setup the uC to use the external crystal with the PLL
        OSCCONbitsCopy.NOSC = 3;
        OSCCONbitsCopy.OSWEN = 1;
    #endif

    // Switch over to the new clock setup
    __builtin_write_OSCCONH( BITS2BYTEH( OSCCONbitsCopy ) );     
    __builtin_write_OSCCONL( BITS2BYTEL( OSCCONbitsCopy ) );
    // Wait for this transfer to take place
    while (OSCCONbits.COSC != OSCCONbits.NOSC);
    // Setup the DIV bits for the FRC, this values means the config word needs to be: PLLDIV_DIV2
    CLKDIVbits.RCDIV0 = 0;

    // Setup the PLL divider for the correct clock frequency
    if (CLOCK_FREQ == 32000000)
    {
        CLKDIVbits.CPDIV = 0;
    }
    else if (CLOCK_FREQ == 16000000)
    {
        CLKDIVbits.CPDIV = 1;
    }
    else if (CLOCK_FREQ == 8000000)
    {
        CLKDIVbits.CPDIV = 2;
    }
    else if (CLOCK_FREQ == 4000000)
    {
        CLKDIVbits.CPDIV = 3;
    }

    // Check that the PLL is enabled again and locked properly to the new setup
    CLKDIVbits.PLLEN = 1;
    // Note - don't want to do this check if we are running in the simulator as it won't work
    #ifndef __MPLAB_SIM
        while(_LOCK != 1);
    #endif

    // Configure port pins
    configurePortPins();


}

/******************************************************************************
 * Function:        inline void configurePortPins()
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function configures the port pins are required by the user application
 *
 *
 * Note:			Users should modify this function as required     
 *
 *****************************************************************************/
inline void configurePortPins(void)
{


    // Turn off analogue functions on all pins
    AD1PCFG = 0xFFFF;

    // Setup LEDs as outputs
    ENABLE_LED_1();
    ENABLE_LED_2();

    // Setup Push button as an input
    ENABLE_BUTTON();


}



