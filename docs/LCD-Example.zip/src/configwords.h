/*
 *	Subsystem		:	nanoTRONICS24 Development Board - LCD Example code
 *
 * 	File Name		:	configwords.h
 * 	
 * 	Author			:	Modtronics Development Team
 * 	
 * 	Creation Date	:	03/11/2013
 * 	
 * 	Description		:	This header file contains the configurations words for the 
 * 	                    the project. Configuration words control the very low level 
 * 	                    hardware functions of the microncontroller.
 * 	                    
 * � Modtronics Australia 2013
 * www.modtronicsaustralia.com
 *
 */

#ifndef CONFIG_WORDS_H
#define CONFIG_WORDS_H

    // Microcontroller config words (fuses) - get these wrong and nothing will work correctly, if at all!!
    _CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & ICS_PGx1 & FWDTEN_OFF & WINDIS_OFF & FWPSA_PR32 & WDTPS_PS8192)
    _CONFIG2(IESO_OFF & FNOSC_FRCPLL & OSCIOFNC_OFF & POSCMOD_NONE & PLL96MHZ_ON & PLLDIV_DIV2 & FCKSM_CSECME & IOL1WAY_OFF)
    _CONFIG3(WPFP_WPFP0 & SOSCSEL_IO & WUTSEL_FST & WPDIS_WPDIS & WPCFG_WPCFGDIS & WPEND_WPENDMEM)
    _CONFIG4(DSWDTPS_DSWDTPS3 & DSWDTOSC_LPRC & RTCOSC_LPRC & DSBOREN_OFF & DSWDTEN_OFF) 

#endif  //CONFIG_WORDS_H
