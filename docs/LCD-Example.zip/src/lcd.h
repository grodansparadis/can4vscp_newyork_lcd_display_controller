/*
 *	Subsystem		:	nanoTRONICS24 Development Board - LCD Library
 *
 * 	File Name		:	lcd.h
 * 	
 * 	Author			:	Modtronics Development Team
 * 	
 * 	Creation Date	:	03/11/2013
 * 	
 * 	Description		:	This module is responsible for initialising, writing to and controlling
 * 	                    the a standard 8x2 or 16x2 alphanumeric LCD module.
 * 	                    Currently this module only supports LCDs in 4-bit mode (ie D4-D7 used). 
 * 	                    Pins are configured in the lcd.h file
 * 	                    
 * � Modtronics Australia 2013
 * www.modtronicsaustralia.com
 *
 */

#ifndef LCD_H
#define LCD_H

#include "HardwareProfile.h"
#include <xc.h>
#include <libpic30.h>
#include <stdint.h>


////////////////////////////////////////////////////////////////////////// 
// Pin Definitions
//////////////////////////////////////////////////////////////////////////
// Pin selection - change this defines to match your pins
#define LCD_RS_PIN LATCbits.LATC6
#define LCD_RW_PIN LATCbits.LATC5
#define LCD_E_PIN  LATCbits.LATC4
#define LCD_D4_PIN LATCbits.LATC0
#define LCD_D5_PIN LATCbits.LATC1
#define LCD_D6_PIN LATCbits.LATC2
#define LCD_D7_PIN LATCbits.LATC3

// Pin selection - change this defines to match your pins
#define LCD_RS_PIN_READ PORTCbits.RC6
#define LCD_RW_PIN_READ PORTCbits.RC5
#define LCD_E_PIN_READ  PORTCbits.RC4
#define LCD_D4_PIN_READ PORTCbits.RC0
#define LCD_D5_PIN_READ PORTCbits.RC1
#define LCD_D6_PIN_READ PORTCbits.RC2
#define LCD_D7_PIN_READ PORTCbits.RC3

// Change these defines to match the pins above
#define LCD_RS_TRIS TRISCbits.TRISC6
#define LCD_RW_TRIS TRISCbits.TRISC5
#define LCD_E_TRIS  TRISCbits.TRISC4
#define LCD_D4_TRIS TRISCbits.TRISC0
#define LCD_D5_TRIS TRISCbits.TRISC1
#define LCD_D6_TRIS TRISCbits.TRISC2
#define LCD_D7_TRIS TRISCbits.TRISC3

////////////////////////////////////////////////////////////////////////// 
// LCD Command Definitions
//////////////////////////////////////////////////////////////////////////
#define LCD_DISP_ON         0x0C    // Display on
#define LCD_DISP_ON_C       0x0E    // Display on, Cursor on
#define LCD_DISP_ON_B       0x0F    // Display on, Cursor on, Blink cursor
#define LCD_DISP_OFF        0x08    // Display off
#define LCD_DISP_CLR        0x01    // Clear the Display
#define LCD_ENTRY_INC       0x06    // Increment-mode, display shift OFF
#define LCD_ENTRY_INC_S     0x07    // Increment-mode, display shift ON
#define LCD_ENTRY_DEC       0x04    // Decrement-mode, display shift OFF
#define LCD_ENTRY_DEC_S     0x05    // Decrement-mode, display shift ON
#define LCD_DD_RAM_ADDR     0x80    // Least Significant 7-bit are for address

////////////////////////////////////////////////////////////////////////// 
// LCD Special Characters Definitions
//////////////////////////////////////////////////////////////////////////
#define LCD_CHAR_LEFT_ARROW          0x7F
#define LCD_CHAR_LEFT_ARROW_STRING   "\x7f"
#define LCD_CHAR_RIGHT_ARROW         0x7E
#define LCD_CHAR_RIGHT_ARROW_STRING  "\x7e"

////////////////////////////////////////////////////////////////////////// 
// Module Function Prototypes
//////////////////////////////////////////////////////////////////////////

/*
 *  Initialise the LCD - Set all the IO pins into the correct mode
 *                       Reset the LCD
 *                       Set the LCD into 4-bit mode
 *                       Setup the font and cursor blinking mode etc
*/
void lcdInitialise( void );

/*
 *  LCD Strobe - this function clocks the data on the pins D4-D7 into
 *  the LCD's buffer
*/
void lcdStrobe( void );

/*
 *  LCD Write Command - this function writes a command to the LCD's
 *  command buffer.
 *  
*/
void lcdWriteCommand( uint8_t iCmd );

/*
 *  LCD Write Character - this function writes a character
 *  to the LCD's character buffer. Note, just like commands
 *  characters need to be written a nibble at a time
 *  
*/
void lcdWriteCharacter( uint8_t iChar );

/*
 *  LCD Printf - this function prints a string of characters
 *  to the LCD.
 *  
*/
void lcdPrintf( const char *iString );

/*
 *  LCD Printf Line One - Print the passed string to the first
 *  line on the LCD
 *  
*/
inline void lcdPrintfLineOne( const char *iString );

/*
 *  LCD Printf Line Two - Print the passed string to the second
 *  line on the LCD
 *  
*/
inline void lcdPrintfLineTwo( const char *iString );

/*
 *  LCD Clear - This function clears the LCD 
 *  
*/
void lcdClear( void );

/*
 *  LCD Write Character Generator RAM (CGRAM) - This function can be
 *  used to create custom characters on the LCD
 *  
*/
void lcdWriteCharGenRAM( uint8_t iCharPosition, const char *iChar );

/*
 *  LCD GOTO Position - This function move the LCD cursor to the
 *  specified position on the screen
 *  
*/
void lcdGotoPosition( uint8_t iPosition );

/*
 *  LCD Turn Off - This function turns off the LCD
 *  
*/
void lcdTurnOff( void );

/*
 *  Scroll LCD Line One - Scroll the first line of the LCD by one character
 *  to the left
 *  
*/
uint8_t lcdScrollLineOne( const char *iString, uint8_t iCurrentPosition );

/*
 *  Scroll LCD Line Two - Scroll the second line of the LCD by one character
 *  to the left
 *  
*/
uint8_t lcdScrollLineTwo( const char *iString, uint8_t iCurrentPosition );


#endif
