/*
 *	Subsystem		:	nanoTRONICS24 Development Board - LCD Example code
 *
 * 	File Name		:	HardwareProfile.h
 * 	
 * 	Author			:	Modtronics Development Team
 * 	
 * 	Creation Date	:	03/11/2013
 * 	
 * 	Description		:	This header file is responsible for the basic config
 * 	                    of the project - this includes pin configurations and
 * 	                    the like
 * 	                    
 * � Modtronics Australia 2013
 * www.modtronicsaustralia.com
 *
 */

// This file has been adapted from the original Microchip provided ones

#ifndef HARDWARE_PROFILE_H
#define HARDWARE_PROFILE_H


    #include <p24FJ64GB004.h>

    // Used for Windows simulation only - won't be used when running on real hardware
    #if defined _WIN32 
        #define __C30__
        #define __PIC24FJ64GB004__
    #endif

    // Hardware specific definitions
    #define PIC24FJ64GB004_PIM
        #ifndef __PIC24FJ64GB004__
        #define __PIC24FJ64GB004__
    #endif
    #define CLOCK_FREQ 32000000ULL			// Use 32MHz clock - default for demo board
    //#define CLOCK_FREQ 16000000ULL		// Use 16MHz clock
    //#define CLOCK_FREQ 8000000ULL		// Use 8MHz clock
    //#define CLOCK_FREQ 4000000ULL		// Use 4MHz clock
    #define GetSystemClock() CLOCK_FREQ
    #define GetPeripheralClock() CLOCK_FREQ
    #define GetInstructionClock() (CLOCK_FREQ / 2)
    #define FCY (CLOCK_FREQ / 2ULL)
    // If the following line is uncommented the uC will use the internal oscillator,
    // comment the line out to use the external oscillator
    #define USE_FRC_CLOCK 

    /* *********************** Specific Pin Definitions *******************/

    // Can be used to turn on or off a specific LED
    #define LED_1				PORTBbits.RB8
    #define LED_2				PORTBbits.RB9
    // Used to enable a LED, ie set the data direction register to an output
    #define ENABLE_LED_1()		TRISBbits.TRISB8 = 0
    #define ENABLE_LED_2()		TRISBbits.TRISB9 = 0

    // Can be used to read the value of the push button
    #define BUTTON				PORTBbits.RB13
    // Used to enable the push button, ie set the data direction register to an input
    #define ENABLE_BUTTON()		TRISBbits.TRISB13 = 1

    // UART pin definitions
    #define UART_TX_TRIS		TRISBbits.TRISB3
    #define UART_TX_IO			PORTBbits.RB3
    #define UART_RX_TRIS		TRISBbits.TRISB8
    #define UART_RX_IO			PORTBbits.RB8

    /** I/O pin definitions ********************************************/
    #define INPUT_PIN 1
    #define OUTPUT_PIN 0

    // Other useful functions

    #define BITS2WORD(sfrBitfield)   ( *((unsigned int*) &sfrBitfield) )
    // Convert a bitfield to a word (unsigned int).
    #define BITS2BYTEL(sfrBitfield)   ( ((uint8_t*) &sfrBitfield)[0] )
    // Return the low byte (as a uint8_t) of a bitfield.
    #define BITS2BYTEH(sfrBitfield)   ( ((uint8_t*) &sfrBitfield)[1] )
    // Return the high byte (as a uint8_t) of a bitfield. 


#endif  //HARDWARE_PROFILE_H
